<div>
    <h1>Tu codigo para crear la cuenta es</h1>
    <p>Hola, tu código es: <strong><?php echo e($user->code); ?></strong></p>

    
    <p>Si no solicitaste este código, puedes ignorar este mensaje.</p>
    <p>Gracias,</p>
    <p>El equipo de soporte</p>
    <p>Nota: Este código es válido por 30 minutos.</p>
    <p>Si tienes problemas, por favor contacta a nuestro soporte.</p>
    <p>Atentamente,</p>
    <p>El equipo de soporte</p>
</div>
<?php /**PATH /Users/usuario/Desktop/PABLO VAZQUEZ ALVARADO/Documentos Pablo Vazquez Alvarado/cargo-loop-api/cargo-loop-api/resources/views/CodeVerificationMail.blade.php ENDPATH**/ ?>