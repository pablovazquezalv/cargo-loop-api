<nav class="flex items-center justify-between px-6 py-4 shadow-sm">
    <div class="text-2xl font-bold">
      <a href="<?php echo e(url('/')); ?>">
        Carga loop
        <img src="/Carga-loop-icon.png" alt="Logo" class="h-8 inline-block" />
      </a>
    </div>
    <ul class="flex space-x-6">
      <li><a href="<?php echo e(url('/')); ?>">Generador de carga</a></li>
      <li><a href="#">Transportista</a></li>
      <li><a href="<?php echo e(url('/')); ?>">¿Quiénes somos?</a></li>
    </ul>
    <div class="flex space-x-3">
      <a href="<?php echo e(url('/login')); ?>" class="px-4 py-1 text-white bg-blue-800 rounded">Iniciar sesión</a>
      <a href="<?php echo e(url('/register')); ?>" class="px-4 py-1 text-white bg-blue-800 rounded">Crear cuenta</a>
    </div>
  </nav>
  <?php /**PATH /Users/usuario/Desktop/PABLO VAZQUEZ ALVARADO/Documentos Pablo Vazquez Alvarado/cargo-loop-api/cargo-loop-api/resources/views/components/navbar.blade.php ENDPATH**/ ?>