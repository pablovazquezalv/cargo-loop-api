<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Carga Loop</title>
  
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .fade-in {
      opacity: 0;
      transform: translateY(-30px);
      animation: fadeIn 0.8s ease-out forwards;
    }
    .fade-delay-1 { animation-delay: 0.4s; }
    .fade-delay-2 { animation-delay: 0.6s; }
    .zoom-in { transform: scale(0.8); animation: zoomIn 0.8s ease-out forwards; animation-delay: 0.8s; }

    @keyframes fadeIn {
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes zoomIn {
      to { opacity: 1; transform: scale(1); }
    }
  </style>
</head>
<body>
<?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>

<div class="flex flex-col items-center justify-center min-h-screen bg-white px-4">
    <img src="<?php echo e(asset('Carga-loop-icon.png')); ?>" alt="Logo" class="h-24 mb-6" />
    <h1 class="text-3xl font-bold text-blue-800 mb-10">Crear Empresa</h1>

    <?php if(session('error')): ?>
        <div class="mb-4 text-red-600"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('manager.createCompany')); ?>" method="POST" enctype="multipart/form-data"
          class="w-full max-w-lg p-8 bg-white rounded-lg shadow-md">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = [
            ['id' => 'name', 'label' => 'Nombre de la Empresa', 'type' => 'text', 'required' => true],
            ['id' => 'business_name', 'label' => 'Razón Social', 'type' => 'text'],
            ['id' => 'email', 'label' => 'Email', 'type' => 'email', 'required' => true],
            ['id' => 'phone', 'label' => 'Teléfono', 'type' => 'text'],
            ['id' => 'address', 'label' => 'Dirección', 'type' => 'text'],
            ['id' => 'city', 'label' => 'Ciudad', 'type' => 'text'],
            ['id' => 'state', 'label' => 'Estado', 'type' => 'text'],
            ['id' => 'country', 'label' => 'País', 'type' => 'text'],
            ['id' => 'postal_code', 'label' => 'Código Postal', 'type' => 'text'],
            ['id' => 'website', 'label' => 'Sitio Web', 'type' => 'url'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label for="<?php echo e($field['id']); ?>" class="block mb-4">
                <span class="text-gray-700"><?php echo e($field['label']); ?></span>
                <input
                    type="<?php echo e($field['type']); ?>"
                    id="<?php echo e($field['id']); ?>"
                    name="<?php echo e($field['id']); ?>"
                    value="<?php echo e(old($field['id'])); ?>"
                    <?php if(!empty($field['required'])): ?> required <?php endif; ?>
                    class="w-full mt-2 p-3 border rounded focus:outline-none focus:ring focus:ring-blue-200"
                />
                <?php $__errorArgs = [$field['id']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <label class="block mb-4">
            <span class="text-gray-700">Imagen de Perfil</span>
            <input
                type="file"
                id="profile_picture"
                name="profile_picture"
                accept="image/*"
                class="w-full mt-2 p-2 border rounded text-sm text-gray-700"
            />
            <?php $__errorArgs = ['profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="block mb-6">
            <span class="text-gray-700">Descripción</span>
            <textarea
                id="description"
                name="description"
                rows="4"
                class="w-full mt-2 p-3 border rounded focus:outline-none focus:ring focus:ring-blue-200"
            ><?php echo e(old('description')); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <button
            type="submit"
            class="w-full py-3 bg-blue-800 text-white rounded hover:bg-blue-900 transition-all"
        >
            Crear Empresa
        </button>
    </form>
</div>
</body>
</html>
<?php /**PATH /Users/usuario/Desktop/PABLO VAZQUEZ ALVARADO/Documentos Pablo Vazquez Alvarado/cargo-loop-api/cargo-loop-api/resources/views/manager/create-company.blade.php ENDPATH**/ ?>