<div>
<h1 class="text-2xl font-bold mb-4">Tu código de invitación</h1>
<p class="mb-4">Hola, tu código de invitación es: <strong><?php echo e($invitation->code); ?></strong></p>
<p class="mb-4">Has hecho clic en el enlace para unirte a la cuenta. Si no fuiste tú, por favor ignora este mensaje.</p>
<p class="mb-4">Si no solicitaste este código, puedes ignorar este mensaje.</p>
<p class="mb-4">Gracias,</p>
</div>
<?php /**PATH /Users/usuario/Desktop/PABLO VAZQUEZ ALVARADO/Documentos Pablo Vazquez Alvarado/cargo-loop-api/cargo-loop-api/resources/views/InvitationMail.blade.php ENDPATH**/ ?>