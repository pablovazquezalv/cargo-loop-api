<?php

namespace App\Models\Roles;

use Illuminate\Database\Eloquent\Model;

class rol extends Model
{
    protected $table = 'roles';
}
