<?php

namespace App\Http\Controllers\Invitations;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class InvitationrController extends Controller
{
    //
}
